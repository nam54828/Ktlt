package chuong_6;
// ham tra ve 1 ky tu trong chuoi
public class vidu6_9 {
    public static void main(String[] args) {
        String chuoi = "Happy new year!";
        char character = chuoi.charAt(4);
        System.out.println(character);
    }
}
