package chuong_6;

public class vidu6_14 {
    public static void main(String[] args) {
        String string = new String("    Welcome to Freetuts.net!    ");
        string = string.trim();
        System.out.println("Chuoi sau khi loai bo khoang trang thua la"+string);
    }
}
