package chuong_6;
// ham noi 2 chuoi ky tu
public class vidu6_8 {
    public static void main(String[] args) {
        String chuoi1= "Happy ", chuoi2 = "new year!";
        String chuoi3= chuoi1.concat(chuoi2);
        System.out.println(chuoi3);
    }
}
