package chuong_6;
// vong lap vo han

public class vidu6_1 {
    static void p(){
        System.out.println("Hello");
        p();
    }

    public static void main(String[] args) {
        p();
    }
}
