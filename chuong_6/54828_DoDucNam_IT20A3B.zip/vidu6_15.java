package chuong_6;

public class vidu6_15 {
    public static void main(String[] args) {
        String chuoicha = new String("Welcome to Freetuts.net!");
        String chuoiCon1 = chuoicha.substring(11);
        System.out.println(chuoiCon1);
        String chuoiCon2 = chuoicha.substring(11,19);
        System.out.println(chuoiCon2);
    }
}
