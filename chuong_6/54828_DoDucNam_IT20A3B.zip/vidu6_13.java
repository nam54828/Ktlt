package chuong_6;

public class vidu6_13 {
    public static void main(String[] args) {
        String string1 = new String("Happy new year!");
        System.out.println(string1.replace('l','r'));
        System.out.println("chuoi sau khi thay the la " + string1.replace('y','r'));
    }
}
