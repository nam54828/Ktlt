package chuong_6;
// Khai bao chuoi ky tu
public class vidu6_5 {
    public static void main(String[] args) {
        String chuoi1 = " ";
        String chuoi2 = "Welcome";
        System.out.println(" Chuoi rong co gia tri: " + chuoi1);
        System.out.println("Chuoi 2 co gia tri: " + chuoi2);
    }
}
