package chuong_6;

public class vidu6_12 {
    public static void main(String[] args) {
        int result;
        String string1 = "Happy new year and new year!";
        String string2 = "new year!";
        result = string1.lastIndexOf(string2);
        System.out.println("Vi tri cuoi cung xuat hien chuoi " + string2 + " trong chuoi " + string1 + " = " + result);
    }
}
