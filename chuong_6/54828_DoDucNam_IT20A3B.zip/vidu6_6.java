package chuong_6;
// Tu khoa NEW
public class vidu6_6 {
    public static void main(String[] args) {
        String chuoi = new String("Welcome to Java!");
        System.out.println(chuoi);
    }
}
