package viduchuong4;

public class Vidu4_9 {
    public static void main(String[] args) {
        String[] cars={"Honda", "BMW", "FORD", "MAZDA", "SUZUKI"};
        System.out.println("Do dai cua mang cars la: "+ cars.length);
    }
}

