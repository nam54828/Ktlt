package viduchuong4;

public class Vidu4_4 {
    public static void main(String[] args) {
        int diem[][] = {{1,2},{3,4},{5,6}};
        System.out.println("Phan tu nam o dong 2 va cot 1 trong mang diem la "+ diem[2][1]);
    }
}
