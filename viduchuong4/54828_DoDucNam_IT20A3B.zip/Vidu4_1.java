package viduchuong4;

public class Vidu4_1 {
    public static void main(String[] args) {
        char[] Kytu = new char [] {'a', 'b', 'c', 'd', 'e'};
        System.out.println("Ký tự tại vị trí thứ 2 của mảng là: "+Kytu[2]);
    }
}
